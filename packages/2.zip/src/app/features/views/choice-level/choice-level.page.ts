import { Router } from '@angular/router';
import { BdService } from 'src/app/services/bd.service';

import { Component, OnInit } from '@angular/core';
 // Assurez-vous de mettre le bon chemin

@Component({
  selector: 'app-choice-level',
  templateUrl: './choice-level.page.html',
  styleUrls: ['./choice-level.page.scss'],
})
export class ChoiceLevelPage implements OnInit {
  niveaux: any[] = [];
  cat: any
  constructor( private router: Router, private bd : BdService) {}

  async ngOnInit() {

    this.bd.getIng4("niveaux").then((rep)=>{
      this.niveaux=rep
      console.log(this.niveaux)
      console.log(rep)
    })

    const navigation = this.router.getCurrentNavigation();

    if (navigation?.extras && navigation.extras.state){
     this.cat = navigation.extras.state['categories']
    }
    // Appelez la fonction getNiveaux du service
  //   try {
  //     this.niveaux = await this.rubriquesService.getNiveaux();
  //     console.log('Niveaux récupérés:', this.niveaux);
  //   } catch (error) {
  //     console.error('Erreur lors de la récupération des niveaux dans choice-level:', error);
  //   }
  // }

  // Fonction appelée lorsque l'utilisateur clique sur un niveau
  

  // allerAuxDetailsRubriques(categorie: any, idNiveau: string) {
  //   this.router.navigate(['/details-rubriques', categorie.id, idNiveau]);
  // }
  }

  onPage(item : any) {

    const datas={
      niv: item.id,
      cat: this.cat
    }
    this.router.navigate(["details-rubriques"], {state: {data: datas}});
  }

  // onPage(item: any){
  //   this.router.navigate(["details-rubriques"], {state: { categories : item.id}});


  // }
}
