import { Component, OnInit } from '@angular/core';
import { Storage } from '@ionic/storage';
import { BdService } from 'src/app/services/bd.service';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { ChangeDetectorRef } from '@angular/core';


@Component({
  selector: 'app-details-rubriques',
  templateUrl: './details-rubriques.page.html',
  styleUrls: ['./details-rubriques.page.scss'],
})
export class DetailsRubriquesPage implements OnInit {
  questions: any[] = [];
  reponses: any[] = [];
  currentIndex: number = 0; // Ajout de la variable currentIndex
  cat: any;
  score: number = 0;
  formattedTime: string = '';
  timeRemaining: number = 120; // 2 minutes en secondes


  constructor(private storage: Storage,private changeDetectorRef: ChangeDetectorRef, private alertController: AlertController, private bd: BdService, private router : Router) {}

  ngOnInit() {
    this.loadQuestionsAndReponses();
    
    

    const navigation = this.router.getCurrentNavigation();

    if (navigation?.extras && navigation.extras.state){
     this.cat = navigation.extras.state['data']
     console.log(this.cat)
    }
  }

 // ...

 async presentQuitOptions() {
  const alert = await this.alertController.create({
    header: 'Options',
    message: 'Que souhaitez-vous faire ?',
    buttons: [
      {
        text: 'Quitter le quiz',
        handler: () => {
          this.leaveQuiz();
        }
      },
      {
        text: 'Quitter la rubrique',
        handler: () => {
          this.leaveCategory();
        }
      },
      {
        text: 'Annuler',
        role: 'cancel'
      }
    ]
  });

  await alert.present();
}

async loadQuestionsAndReponses() {
  try {
    const storedQuestions = await this.storage.get('questions');
    const storedReponses = await this.storage.get('reponses');


    if ( storedQuestions && storedQuestions.length > 0) {
      // const questionId = this.questions[this.currentIndex].id;
      // const reponsesData = await this.bd.getListReponsesByQuestionId(questionId);
      for( let i=0; i < storedQuestions.length; i++){
          if(this.cat.niv===storedQuestions[i].niveaux_id && this.cat.cat===storedQuestions[i].categories_id){
            this.questions.push(storedQuestions[i])
          }
      }
      //this.questions = storedQuestions;
      console.log(this.questions)
      this.reponses = storedReponses;
      //
        
        this.loadReponses();
      //   }
      // }

      this.timeRemaining = 120; // Réinitialisez le compte à rebours pour chaque nouvelle question
      this.startTimer(); // Démarrez le compte à rebours 
      
    } else {
      console.warn('Aucune question trouvée dans le stockage local.');
    }
  } catch (error) {
    console.error('Erreur lors de la récupération des questions et réponses', error);
  }
}

leaveQuiz() {
  this.router.navigate(['/onboarding']); // Remplacez '/accueil' par le chemin de la page d'accueil
}

leaveCategory() {
  this.router.navigate(['/rubriques']); // Remplacez '/selection-rubrique' par le chemin de la page de sélection de rubrique
}

// ...

startTimer() {
  setInterval(() => {
    if (this.timeRemaining > 0) {
      const minutes = Math.floor(this.timeRemaining / 60);
      const seconds = this.timeRemaining % 60;
      const formattedTime = this.formatTime(minutes, seconds);

      // Mise à jour de la variable
      this.formattedTime = formattedTime;

      // Détection des modifications
      this.changeDetectorRef.detectChanges();

      this.timeRemaining--;
    } else {
      this.handleTimeout();
    }
  }, 1000);
}

// Fonction pour formater le temps en minutes et secondes
formatTime(minutes: number, seconds: number): string {
  const formattedMinutes = String(minutes).padStart(2, '0');
  const formattedSeconds = String(seconds).padStart(2, '0');
  return `${formattedMinutes}:${formattedSeconds}`;
}

handleTimeout() {
  // Implémentez le comportement souhaité, par exemple, passer automatiquement à la question suivante
  this.nextQuestion();
}

async selectAnswer(reponse: any) {

    if (reponse.est_correct.toLowerCase()==="vrai" || reponse.est_correct.toLowerCase()==='1' ){
      this.score=reponse.points+this.score
      this.nextQuestion();
  
     }
        
     else {
      console.error('Réponse non trouvée pour la question actuelle.');
  
}
}





// Ajoutez la méthode handleButtonClick à votre fichier TypeScript
handleButtonClick(reponse: string) {
  this.nextQuestion();
  this.selectAnswer(reponse);
}




  // Méthode pour passer à la question suivante
  nextQuestion() {
    if (this.currentIndex < this.questions.length - 1) {
      this.currentIndex++;
      // Charger les réponses pour la nouvelle question
      this.loadReponses();
  
    } else {
      
      this.router.navigate(['/congratulations', { score: this.score }]);
      console.log('Vous avez atteint la dernière question.');
    }
  }

  

  // Méthode pour charger les réponses de la question actuelle
  async loadReponses() {
    try {
      if (this.questions.length > 0 && this.currentIndex < this.questions.length) {
        const questionId = this.questions[this.currentIndex].id;
        const reponsesData = await this.bd.getListReponsesByQuestionId(questionId);


        if (reponsesData) {
          this.reponses = reponsesData;
          console.log(this.reponses)
        } else {
          console.error('Réponses non disponibles pour la question actuelle.');
        }
      } else {
        console.error('ID de question non valide ou currentIndex hors limites.');
      }
    } catch (error) {
      console.error('Erreur lors de la récupération des réponses', error);
    }
  }

}
